package com.dao;

public interface CategoryDao2 {

	String getCategory="SELECT * FROM category WHERE categoryID=?";
}
