package com.dao;

public interface TimeDao {

	String getTime="SELECT SYSDATE FROM DUAL";
}
