package com.dao;



public interface FileDao {

	String Upload="INSERT INTO UPLOAD_FILE VALUES (?,?,?)";
	
}
