package com.dao;



public interface FileDao2 {

	String Upload="INSERT INTO UPLOAD_FILE2 VALUES (?,?,?)";
	
}
