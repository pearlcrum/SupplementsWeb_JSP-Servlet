package com.dao;

public interface CategoryDao {

	String getCategory="SELECT * FROM category WHERE categoryID=?";
}
